from setuptools import setup

setup(
    long_description="dj-dj-dj-maintenance is a Django app to conduct sheduled dj-dj-maintenance on your web application. Detailed documentation is in the 'docs' directory."
)