from setuptools import setup

setup(
name = "dj_maintenance",
version = "0.1.1",
long_description="dj_maintenance is a Django app to conduct sheduled dj-dj_maintenance on your web application. Detailed documentation is in the 'docs' directory."
)