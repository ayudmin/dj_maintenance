from setuptools import setup

setup(
    long_description="django_maintenance is a Django app to conduct sheduled maintenance on your web application.Detailed documentation is in the 'docs' directory."
)