from setuptools import setup

setup(
    long_description="dj_maintenance is a Django app to conduct sheduled dj-dj_maintenance on your web application. Detailed documentation is in the 'docs' directory."
)