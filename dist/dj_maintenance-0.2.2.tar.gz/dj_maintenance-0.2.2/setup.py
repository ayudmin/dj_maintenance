from setuptools import setup

setup(
name = "dj_maintenance",
version = "0.2.2",
long_description="dj_maintenance is a Django app to conduct sheduled dj-dj_maintenance on your web application. Detailed documentation is in the 'docs' directory."
)